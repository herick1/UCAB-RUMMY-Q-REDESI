/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rummy.q.Modelo;
import javax.swing.JButton;

/**
 *
 * @author herick
 */
public class Teclas extends JButton {
    public String numero;
    public String color;
    
    public Teclas(){

        numero ="";
        color= null;
    }
}
